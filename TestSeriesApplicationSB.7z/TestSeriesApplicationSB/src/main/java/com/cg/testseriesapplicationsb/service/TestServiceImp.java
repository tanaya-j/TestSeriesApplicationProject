package com.cg.testseriesapplicationsb.service;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesapplicationsb.dto.Question;
import com.cg.testseriesapplicationsb.dto.Test;
import com.cg.testseriesapplicationsb.exception.TestNotFoundException;
import com.cg.testseriesapplicationsb.repository.TestRepository;

/*This class is implementation of test service interface which implements create test ,search test 
 * by name  methods..!
 * last Modified 27/05/2019 Author:Tanaya Jadhav 
*/
@Transactional
@Service
public class TestServiceImp implements TestService{

	@Autowired
	TestRepository dao;
	static int testid=1;
	static int questionId=1;
	
	static final Logger logger = Logger.getLogger(TestServiceImp.class); 
/*creates test
	 * @param: Test
	 * @return: test
	 last Modified 27/05/2019  Author:Tanaya Jadhav
*/
	public Test createMyTest(Test test) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("D:\\NewWorkspace\\TestSeriesApplicationSB\\src\\main\\resources\\log4j.properties");  
		test.setId(testid);
		for(Question que : test.getQuestions()) {
		    que.setId(questionId);
			questionId++;
		}
		testid++;
	    logger.info("ADDING TESTS..!!!!");
		return dao.save(test);
	}

/*searches test by name
	 * @param: testname
	 * @return: test with that name 
	 * last Modified 27/05/2019 Author:Tanaya Jadhav
*/
	public Test searchTestByName(String testName) {
		PropertyConfigurator.configure("D:\\NewWorkspace\\TestSeriesApplicationSB\\src\\main\\resources\\log4j.properties");
		Test t=dao.findByName(testName);
		if(t==null) {
			throw new TestNotFoundException("Test not created..!!");
		}
		 logger.info("SEARCHING TESTS BY NAME..!!!!");
		return t;
	}

/*searches test by name
	 * @param: testname
	 * @return: test with that name 
	 * last Modified 27/05/2019 Author:Tanaya Jadhav
*/
	public Test searchTestById(int id) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("D:\\NewWorkspace\\TestSeriesApplicationSB\\src\\main\\resources\\log4j.properties");
		Test t=dao.findByid(id);
		if(t==null) {
			throw new TestNotFoundException("Test not created..!!");
		}
		logger.info("SEARCHING TESTS BY ID..!!!!");
		return t;
	}

}
