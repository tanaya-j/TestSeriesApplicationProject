package com.cg.testseriesapplicationsb.service;

import com.cg.testseriesapplicationsb.dto.Assigner;

/*
 * This is the test assigner interface which includes method that assigns test to candidate
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */
public interface TestAssignerService {
	public Assigner assignTestToCandidate(Assigner assigner);
}
