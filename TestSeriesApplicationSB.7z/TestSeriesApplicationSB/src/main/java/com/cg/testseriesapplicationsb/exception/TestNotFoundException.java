package com.cg.testseriesapplicationsb.exception;

@SuppressWarnings("serial")
public class TestNotFoundException extends RuntimeException {

	public TestNotFoundException() {
		
	}

	

	public TestNotFoundException(String msg) {
		
		super(msg);
	}

}
