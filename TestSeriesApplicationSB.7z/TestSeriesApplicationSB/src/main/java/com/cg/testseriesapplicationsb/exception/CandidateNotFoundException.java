package com.cg.testseriesapplicationsb.exception;

@SuppressWarnings("serial")
public class CandidateNotFoundException extends RuntimeException {

	public CandidateNotFoundException() {
		
	}

	public CandidateNotFoundException(String message) {
		super(message);
		
	}

	

}
