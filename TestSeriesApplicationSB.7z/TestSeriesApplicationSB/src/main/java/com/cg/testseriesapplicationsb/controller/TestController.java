package com.cg.testseriesapplicationsb.controller;

import java.util.Date;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.cg.testseriesapplicationsb.dto.Assigner;
import com.cg.testseriesapplicationsb.dto.Candidate;

import com.cg.testseriesapplicationsb.dto.Test;
import com.cg.testseriesapplicationsb.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationsb.exception.TestNotFoundException;
import com.cg.testseriesapplicationsb.service.CandidateService;
import com.cg.testseriesapplicationsb.service.TestAssignerService;
import com.cg.testseriesapplicationsb.service.TestService;

/*This a controller class
 * last Modified 27/05/2019 Author:Tanaya Jadhav 
*/

@RestController
@RequestMapping("/test")
public class TestController {
	@Autowired
	TestService tservice;
	@Autowired
	CandidateService cservice;
	@Autowired
	TestAssignerService aservice;
	
	  /* This method map to http://localhost:9098/test/addtest
	 * @param Model Attribute Test
	 * @return response entity
	 * 
    * */ 
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(method=RequestMethod.POST,value="/addtest" )
	public ResponseEntity<Test> addTest(@ModelAttribute Test test){
			
	
		Test t1=tservice.createMyTest(test);
		return new ResponseEntity<Test>(t1,HttpStatus.OK);
	}
	
	    /* This method map to http://localhost:9098/test/addCandidate
		 * @param Model Attribute Candidate
		 * @return response entity
		 * 
	 * */ 
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(method=RequestMethod.POST,value="/addCandidate" )
	public ResponseEntity<Candidate> addCandidate(@ModelAttribute Candidate candidate){
			
		Candidate c=cservice.addCandidate(candidate);
		return new ResponseEntity<Candidate>(c,HttpStatus.OK);
	}
	
	 /* This method map to http://localhost:9098/test/searchTest
	 * @param Model Attribute Test
	 * @return response entity
	 * 
   * */ 
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(method=RequestMethod.GET,value="/searchTest")
	public ResponseEntity<Test>search(@RequestParam String name) {
	Test t= tservice.searchTestByName(name);
	/*if(t==null)
	{
		return new ResponseEntity("Test not added",HttpStatus.NOT_FOUND);
	}*/
	return new ResponseEntity<Test>(t,HttpStatus.OK);
	}
	
	
	 /* This method map to http://localhost:9098/test/assignTest
	 * @param Model Attribute assigner
	 * @return response entity
	 * 
   * */ 
	@CrossOrigin(origins="http://localhost:4200")
	@SuppressWarnings({"unchecked","rawtypes"})
	@RequestMapping(method=RequestMethod.POST,value="/assignTest")
	public ResponseEntity<Assigner>assign(@ModelAttribute Assigner assigner  ) 
	{
		assigner.setDate(new Date(System.currentTimeMillis()));
		
		Test tid=tservice.searchTestById(assigner.getTest().getId());
		if(tid==null) {
			return new ResponseEntity("Test with this id not found..!!",HttpStatus.NOT_FOUND);
		}
		Candidate cid=cservice.searchById(assigner.getCandidate().getId());
		if(cid==null) {
			return new ResponseEntity("Candidate with this id not found..!!",HttpStatus.NOT_FOUND);
		}
	Assigner a=aservice.assignTestToCandidate(assigner);
	return new ResponseEntity<Assigner>(a,HttpStatus.OK);
	}
	
	/* This method is used to handle Candidate Exception
	 * @param CandidateNotFoundException
	 * @return response entity
	 * 
 * */ 
    @ExceptionHandler({CandidateNotFoundException.class})
		public ResponseEntity<String> handleCandidateException(CandidateNotFoundException be) {

    	return new ResponseEntity<String>(be.getMessage(),HttpStatus.NOT_FOUND);
	    }
	
   
    /* This method is used to handle Test Exception
	 * @param TestNotFoundException
	 * @return response entity
	 * 
 * */ 
    @ExceptionHandler({TestNotFoundException.class})
	public ResponseEntity<String> handleTestException(TestNotFoundException be) {
    	return new ResponseEntity<String>(be.getMessage(),HttpStatus.NOT_FOUND);
		
	}  
}


