package com.cg.testseriesapplicationsb.service;

import com.cg.testseriesapplicationsb.dto.Test;

/*
 * This a test interface it includes methods for creating test ,searching test by name and id
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */

public interface TestService {
	public Test createMyTest(Test test);
	public Test searchTestByName(String testName);
	public Test searchTestById(int id);
}
