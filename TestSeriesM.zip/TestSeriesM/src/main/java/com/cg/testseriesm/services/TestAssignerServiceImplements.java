package com.cg.testseriesm.services;


import com.cg.testseriesm.dao.TestAssignerRepository;
import com.cg.testseriesm.dao.TestAssignerRepositoryImp;
import com.cg.testseriesm.dto.Assigner;

/*
 * This class implements the test assigner service interface*/
public class TestAssignerServiceImplements implements TestAssignerService {

TestAssignerRepository assignerDao;
	
	public TestAssignerServiceImplements() {
		
		assignerDao=new TestAssignerRepositoryImp();
	}
	
	//assigns test to candidate
	public Assigner assignTestToCandidate(Assigner assigner) {
		// TODO Auto-generated method stub
		return assignerDao.save(assigner);
	}

	

}
