package com.cg.testseriesm.dao;

import com.cg.testseriesm.dto.Assigner;

/*
 * This a Test assigner repository  interface  */
public interface TestAssignerRepository {
	public Assigner save(Assigner assigner); 
	
}
