package com.cg.testseriesm.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.testseriesm.dto.Assigner;
import com.cg.testseriesm.exception.CandidateNotFoundException;
import com.cg.testseriesm.exception.TestNotFoundException;
import com.cg.testseriesm.util.DbUtil;

/*
 * This class implements the test assigner repository interface*/
public class TestAssignerRepositoryImp implements TestAssignerRepository {

	/*This method saves the assigned test .If the candidate is already assigned a test then second test cannot
	 * be assigned to the same candidate*/
	public Assigner save(Assigner assigner) {
		
		Connection con=DbUtil.getConnection();
		String query_insert = "INSERT INTO assigner VALUES(?,?,?,?)";
		String query_find = "SELECT CandidateId from assigner where CandidateId=?";
		PreparedStatement pstmt =null;
		//PreparedStatement pstmtOne =null;
		try {
		pstmt =con.prepareStatement(query_find);
		pstmt.setInt(1, assigner.getCandidate().getId());
		ResultSet rs= pstmt.executeQuery();//used when using SELECT clause
		
		if(rs.next()==false) {
				pstmt=con.prepareStatement(query_insert);
				pstmt.setInt(1, assigner.getId());
				pstmt.setInt(2,assigner.getCandidate().getId());
				pstmt.setInt(3, assigner.getTest().getId());
				pstmt.setDate(4,assigner.getDate());
				pstmt.executeUpdate();//compiles once and insert all data
			}else {
				throw new CandidateNotFoundException("Test cannot be assigned!!!");
			}
		
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			 throw new CandidateNotFoundException("Duplicate Assigner id ..!");
		}finally {
		  	 try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					
					throw new TestNotFoundException("Connection not closed...");
				}
		   }
	return null;
		}
}
/*Connection con=DbUtil.getConnection();
String query_insert = "INSERT INTO assigner VALUES(?,?,?,?)";
PreparedStatement pstmt =null;

try {
	
	pstmt=con.prepareStatement(query_insert);
	pstmt.setInt(1, assigner.getId());
	pstmt.setInt(2,assigner.getCandidate().getId());
	pstmt.setInt(3, assigner.getTest().getId());
	pstmt.setDate(4,(Date) assigner.getDate());
	pstmt.executeUpdate();
	
}
	
 catch (SQLException e) {
	// TODO Auto-generated catch block
      throw new CandidateNotFoundException("Test is already assigned to this candidate");
}
return null;
}*/