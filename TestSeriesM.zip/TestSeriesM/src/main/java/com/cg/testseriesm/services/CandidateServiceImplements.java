package com.cg.testseriesm.services;

import com.cg.testseriesm.dao.CandidateRepositoryImp;
import com.cg.testseriesm.dto.Candidate;
import com.cg.testseriesm.exception.CandidateNotFoundException;

/*
 * This class is a implementation of candidate service*/
public class CandidateServiceImplements implements CandidateService {

	CandidateRepositoryImp dao;
	public CandidateServiceImplements() {
		dao=new CandidateRepositoryImp();}
	
	//add the candidate
	public Candidate addCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		return dao.saveCandidate(candidate);
	}

	//search the candidate by Id
	public Candidate searchById(int id) {
		// TODO Auto-generated method stub
		
		return dao.findById(id);
	}

}
