package com.cg.testseriesm.dto;
/*
 * This a Candidate bean class with the attributes as id,name
 * Parameterized constructor , getter setters and toString methods..!*/
public class Candidate {
	   private int id;//primary key
	   private String name;
    
  
  public Candidate() {}

	public Candidate(int id, String name) {
		super();
		this.id = id;
		this.name = name;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	@Override
	public String toString() {
		return "Candidate [Id=" + id + ", name=" + name +  "]";
	}
  
}
