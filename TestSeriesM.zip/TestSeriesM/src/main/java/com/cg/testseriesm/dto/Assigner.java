package com.cg.testseriesm.dto;

import java.sql.Date;

import com.cg.testseriesm.dto.Candidate;
import com.cg.testseriesm.dto.Test;
/*
 * This a Assigner bean class with the attributes as id,date,test(Object of class Test),candidate(Object of
 *  class candidate).
 * Parameterized constructor , getter setters and toString methods..!*/
public class Assigner {

	    private int id;//primary key
	    private	Date date;
		private Test test;
		private Candidate candidate;
		
		public Assigner() {}

		public Assigner(int id, Date date, Test test, Candidate candidate) {
			super();
			this.id = id;
			this.date = date;
			this.test = test;
			this.candidate = candidate;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

		public Test getTest() {
			return test;
		}

		public void setTest(Test test) {
			this.test = test;
		}

		public Candidate getCandidate() {
			return candidate;
		}

		public void setCandidate(Candidate candidate) {
			this.candidate = candidate;
		}

		@Override
		public String toString() {
			return "Assigner [id=" + id + ", date=" + date + ", test=" + test + ", candidate=" + candidate + "]";
		}
		
		
		
}
