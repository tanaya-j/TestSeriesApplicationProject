package com.cg.testseriesm.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.testseriesm.dto.Assigner;

public class DbUtilAssigner {
	 public static List<Assigner> assigner  = new ArrayList<Assigner>();
}
