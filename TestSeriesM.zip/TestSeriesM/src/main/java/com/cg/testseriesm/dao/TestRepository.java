package com.cg.testseriesm.dao;

import com.cg.testseriesm.dto.Test;

public interface TestRepository {
	public Test saveTest(Test test);
	public Test findByName(String testName);
	public Test findById(int id);
}
