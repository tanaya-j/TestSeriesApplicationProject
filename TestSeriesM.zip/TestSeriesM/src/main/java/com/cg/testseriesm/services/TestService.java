package com.cg.testseriesm.services;

import com.cg.testseriesm.dto.Test;

/*
 * This a test interface it includes methods for creating test ,searching test by name and Id*/
public interface TestService {
	public Test createMyTest(Test test);
	public Test searchTestByName(String testName);
	public Test searchTestById(int id);
}
