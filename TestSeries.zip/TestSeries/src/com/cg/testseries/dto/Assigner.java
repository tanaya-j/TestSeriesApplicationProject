package com.cg.testseries.dto;

import java.util.Date;

public class Assigner {
	    private	Date date;
		private Test test;
		private Candidate candidate;
		
		public Assigner() {}

		public Assigner(Date date, Test test, Candidate candidate) {
			super();
			this.date = date;
			this.test = test;
			this.candidate = candidate;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

		public Test getTest() {
			return test;
		}

		public void setTest(Test test) {
			this.test = test;
		}

		public Candidate getCandidate() {
			return candidate;
		}

		public void setCandidate(Candidate candidate) {
			this.candidate = candidate;
		}

		@Override
		public String toString() {
			return "Assigner [date=" + date + ", test=" + test + ", candidate=" + candidate + "]";
		}
		
		
}
