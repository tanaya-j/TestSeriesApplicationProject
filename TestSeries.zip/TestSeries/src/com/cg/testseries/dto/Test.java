package com.cg.testseries.dto;

import java.math.BigInteger;
import java.util.List;



public class Test {
	private String name;
	private BigInteger totalquestions;
	private BigInteger totalMarks;
	private List<Question> questions;
	
	public Test() {}

	public Test(String name, BigInteger totalquestions, BigInteger totalMarks, List<Question> questions) {
		super();
		this.name = name;
		this.totalquestions = totalquestions;
		this.totalMarks = totalMarks;
		this.questions = questions;
	}

	public String getTestName() {
		return name;
	}

	public void setTestName(String testName) {
		this.name = testName;
	}

	public BigInteger getTotalquestions() {
		return totalquestions;
	}

	public void setTotalquestions(BigInteger totalquestions) {
		this.totalquestions = totalquestions;
	}

	public BigInteger getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(BigInteger totalMarks) {
		this.totalMarks = totalMarks;
	}

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Test [testName=" + name + ", totalquestions=" + totalquestions + ", totalMarks=" + totalMarks
				+ ", questions=" + questions + "]";
	}

	
	
}

