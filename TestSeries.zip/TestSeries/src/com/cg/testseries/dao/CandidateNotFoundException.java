package com.cg.testseries.dao;

public class CandidateNotFoundException extends RuntimeException {

	public  CandidateNotFoundException() {super();}
	public  CandidateNotFoundException(String msg) {super(msg);}
	
}
