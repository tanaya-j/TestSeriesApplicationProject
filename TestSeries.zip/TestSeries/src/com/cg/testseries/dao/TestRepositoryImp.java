package com.cg.testseries.dao;

import java.util.ArrayList;
import java.util.List;


import com.cg.testseries.dto.Test;
import com.cg.testseries.util.DbUtilTest;

public class TestRepositoryImp implements TestRepository{

   
	
	@Override
	public Test saveTest(Test test) {
		//return DbUtilTest.myTests.put(test.getTestName(), test);
		DbUtilTest.myTestList.add(test);
		return test;
	}

	@Override
	public Test findByName(String testName) {
		
		for(Test myTestName: DbUtilTest.myTestList)
			if(myTestName.getTestName().equals(testName)) {
				return myTestName;
			}
			else {
				throw new TestNotFoundException("Test is not created");
			}
	      	return null;
		//return new ArrayList<Test>(DbUtilTest.myTests.values());
		//return (List<Test>) DbUtilTest.myTests.get(testName);
	}
}
