package com.cg.testseries.dao;

import java.util.ArrayList;
import java.util.List;


import com.cg.testseries.dto.Candidate;
import com.cg.testseries.util.DBUtilCandidate;

public class CandidateRepositoryImp implements CandidateRepository {

	List<Candidate> myCandidate;
	public CandidateRepositoryImp() {
		myCandidate=new ArrayList<Candidate>();
	}
	@Override
	public Candidate saveCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		DBUtilCandidate.myCandidates.add(candidate);
		return candidate;
	}

	@Override
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
		//List<Candidate> canSearch=new ArrayList();
		for (Candidate candidate : DBUtilCandidate.myCandidates) 
			if(candidate.getId()==id) {
			
				return  candidate;
			}
			else {
				    throw new CandidateNotFoundException("id not found");
			     }
		return null;
	
		
	}

}
