package com.cg.testseries.ui;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.testseries.dao.CandidateNotFoundException;
import com.cg.testseries.dao.TestNotFoundException;
import com.cg.testseries.dto.Assigner;
import com.cg.testseries.dto.Candidate;
import com.cg.testseries.dto.Question;
import com.cg.testseries.dto.Test;
import com.cg.testseries.service.CandidateService;
import com.cg.testseries.service.CandidateServiceImp;
import com.cg.testseries.service.TestAssignerService;
import com.cg.testseries.service.TestAssignerServiceImp;
import com.cg.testseries.service.TestService;
import com.cg.testseries.service.TestServiceImp;
import com.cg.testseries.util.DBUtilAssigner;
import com.cg.testseries.util.DBUtilCandidate;
import com.cg.testseries.util.DbUtilTest;

public class MyMain {
	
	   static TestService services;
	   static TestAssignerService assignerServices;
	   static CandidateService candidateServices; 
	   public static void main(String[] args) {
		
		services=new TestServiceImp();
		assignerServices=new TestAssignerServiceImp();
		//candidateServices=new CandidateServiceImp();
		Test test=null;
		
		Assigner assigner=null;
		Scanner scr=new Scanner(System.in);
		int choice=0;
		int id;
		
	do {
			
			printDetails();
			System.out.println("Enter choice");
			choice=scr.nextInt();
			
			switch(choice) {
		
			case 1:System.out.println("Enter test name:");
			       String testName=scr.next();
			       System.out.println("Enter the total no of questions");
			       BigInteger totalquestions=scr.nextBigInteger();
			       System.out.println(" total marks");
			       BigInteger totalMarks=scr.nextBigInteger();
			      
			        test=new Test(testName, totalquestions,totalMarks , DbUtilTest.myQuestionList);
			       services.createMyTest(test); 
			       System.out.println(services.createMyTest(test));
			    	   
			  break;
			       
			       
			case 2:System.out.println("Enter the test to be searched:");
			       String tname=scr.next();
			       try {
			       Test testdetails= services.searchTestByName(tname);
			       System.out.println(testdetails);
			       }catch(TestNotFoundException e) {
			    	   System.out.println(e.getMessage());
			       }
			  break;
			
			/*case 3:System.out.println("Enter the candidate id:");
				    id=scr.nextInt();
				   System.out.println("Enter the candidate name:");
				   String name=scr.next();
				   
				   candidate=new Candidate();
				   candidate.setId(id);
				   candidate.setName(name);
				   
				   candidateServices.addCandidate(candidate);
				   System.out.println(candidateServices.addCandidate(candidate));
				   
			  break;*/
			
			case 3:/*System.out.println("Enter the id of the candidate to whom test is to be assigned");
			       int cid=scr.nextInt();
			       try {
			    	   candidate=candidateServices.searchById(cid);
			     }catch(CandidateNotFoundException e) {System.out.println(e.getMessage()); break;}*/
				   System.out.println("Enter candidate id:");
				   int cid=scr.nextInt();
				   System.out.println("Enter candidate name:");
				   String cname=scr.next();
			       System.out.println("Enter the name of test:");
			       String testname=scr.next();
			       try { 
				    	 test= services.searchTestByName(testname);
				     }catch(TestNotFoundException e) {
				    	 System.out.println(e.getMessage());
				    	 break;
				     }
			       System.out.println("Enter date:");
			       Date date=new Date();
			       System.out.println(date.getDate());
			       Candidate candidate=new Candidate(cid,cname);
			       assigner=new Assigner(date,test,candidate);
			       assignerServices.assignTestToCandidate(assigner);
			       System.out.println(assignerServices.assignTestToCandidate(assigner));
			      // List<Assigner> assignedTests= assignerServices.assignTestToCandidate(assigner);
			        //for(Assigner assigned:assigner)
			        	//System.out.println(assigned);
			      /* Test test1=new Test();
			       Candidate cand1=new Candidate();
			       
			       for(Test t : DbUtilTest.myTestList) {
			    	   for(Candidate cand :DBUtilCandidate.myCandidates) {
			    		   if(test.getTestName().equals(testname))
			    			   if(candidate.getId()==cid)
			    				   test1=t;
			    		           cand1=cand;
			    				   }
			       }
			       assigner=new Assigner(date,test,candidate);
			       List<Assigner> assignedTests= assignerServices.assignTestToCandidate(assigner);
			        for(Assigner assigned:assignedTests)
			        	System.out.println(assigned);*/
			       
			      // candidate=candidateServices.searchById(cid);
			        /*if(test.getTestName().equals(testname))
			    	   test.setTestName(testname);
			       if(candidate.getId()==cid)
			    	   candidate.setId(cid);*/
			     
			   
			    
			   break;
			}
		}while(choice!=5);
	} 
	
	public static void printDetails() {
		System.out.println("1. Create Test");
		System.out.println("2. Find   Test");
		//System.out.println("3. Add    Candidates");
		System.out.println("3. Assign Test");
	   }
}
