package com.cg.testseries.service;

import java.util.List;

import com.cg.testseries.dao.CandidateRepositoryImp;
import com.cg.testseries.dto.Candidate;

public class CandidateServiceImp implements CandidateService{

	CandidateRepositoryImp dao;
	public CandidateServiceImp() {
		dao=new CandidateRepositoryImp();
	}
	@Override
	public Candidate addCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		return dao.saveCandidate(candidate);
	}
     @Override
	public Candidate searchById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

}
