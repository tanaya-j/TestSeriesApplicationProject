package com.cg.testseries.service;

import java.util.List;

import com.cg.testseries.dto.Candidate;

public interface CandidateService {

	  public Candidate addCandidate(Candidate candidate);
      public Candidate searchById(int id);
}
