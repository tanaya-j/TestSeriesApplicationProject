package com.cg.testseries.service;

import java.util.List;
import com.cg.testseries.dao.TestRepository;
import com.cg.testseries.dao.TestRepositoryImp;
import com.cg.testseries.dto.Test;

public class TestServiceImp implements TestService{

	TestRepository dao;
	
	public TestServiceImp() {
		
		dao= new TestRepositoryImp();
	}
	
	@Override
	public Test createMyTest(Test test) {
		// TODO Auto-generated method stub
		return dao.saveTest(test);
	}

	@Override
	public Test searchTestByName(String testName) {
		// TODO Auto-generated method stub
		return dao.findByName(testName);
	}

	
	
}
