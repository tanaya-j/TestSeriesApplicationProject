package com.cg.testseries.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.cg.testseries.dto.Assigner;
import com.cg.testseries.dto.Candidate;
import com.cg.testseries.dto.Test;

public class DBUtilAssigner {

	  public static List<Assigner> assigner  = new ArrayList<Assigner>();
}
