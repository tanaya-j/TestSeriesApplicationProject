package com.cg.testseriesspring.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.cg.testseriesspring.dto.Assigner;
import com.cg.testseriesspring.dto.Candidate;
import com.cg.testseriesspring.dto.Test;

public class DBUtilAssigner {

	  public static List<Assigner> assigner  = new ArrayList<Assigner>();
}
