package com.cg.testseriesspring.dao;

import java.util.List;

import com.cg.testseriesspring.dto.Assigner;
import com.cg.testseriesspring.dto.Candidate;
import com.cg.testseriesspring.dto.Test;
/*
 * This a Test assigner repository  interface It saves the assigner
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav  */
public interface TestAssignerRepository {
	public Assigner save(Assigner assigner); 
}
