package com.cg.testseriesspring.dto;

import java.math.BigInteger;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
/*
* This a Candidate bean class with the attributes as int id, String name
* Parameterized constructor , getter setters and toString methods..!
* last Modified 15/05/2019
 * Author:Tanaya Jadhav  */

@Component("Candidate")
@Scope("prototype")
public class Candidate {

	   private int id;
	   private String name;
      
    
    public Candidate() {}

	public Candidate(int id, String name) {
		super();
		this.id = id;
		this.name = name;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	@Override
	public String toString() {
		return "Candidate [Id=" + id + ", name=" + name +  "]";
	}
    
    
}
