package com.cg.testseriesspring.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.testseriesspring.exception.CandidateNotFoundException;
import com.cg.testseriesspring.exception.TestNotFoundException;
import com.cg.testseriesspring.dto.Question;
import com.cg.testseriesspring.config.JavaConfig;
import com.cg.testseriesspring.dto.Assigner;
import com.cg.testseriesspring.dto.Candidate;
import com.cg.testseriesspring.dto.Test;
import com.cg.testseriesspring.service.CandidateService;
import com.cg.testseriesspring.service.TestAssignerService;
import com.cg.testseriesspring.service.TestAssignerServiceImp;
import com.cg.testseriesspring.service.TestService;
import com.cg.testseriesspring.service.TestServiceImp;
import com.cg.testseriesspring.util.DbUtilTest;

/*
 * This a main class 
 * Last Modified 15/05/2019
 * Author:Tanaya Jadhav 
 *
*/

@Component
public class MyMain {
	//Auto-wired annotation is used to inject one bean into another
       @Autowired
	   private   TestService testservices;
       @Autowired
       private   TestAssignerService testassignerServices;
       @Autowired
       private  CandidateService candidateService; 
       
       private static TestService services;
       private static TestAssignerService assignerServices;
       private static CandidateService candidateServices; 
	   
	 //post construct annotation is used to create an instance after creating a bean
       @PostConstruct
	   public void init() {
	   		services = this.testservices;
	   		assignerServices = this.testassignerServices;
	   		candidateServices = this.candidateService;
	   	}
		
	  
	   public static void main(String[] args) {

		   AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(JavaConfig.class);
		   Scanner scr=new Scanner(System.in);
		   int choice=0;
		   int id;
		   List<Question> myQuestions;
		 //  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));//to read lines
		   BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		do {
				
				printDetails();
				System.out.println("Enter choice");
				choice=scr.nextInt();
				
				switch(choice) {
			
				/*
				 * case for creating test
				 * It creates and saves test
				 last Modified 15/05/2019 
				*/
				case 1:    System.out.println("Enter test name:");
				           String testName= scr.next();
				           System.out.println("Enter the total no of questions");
				           BigInteger totalquestions=scr.nextBigInteger();
				           System.out.println("Enter total marks");
				           BigInteger totalMarks=scr.nextBigInteger();
				           Test test=(Test) app.getBean("Test");
				          // Question  question=(Question) app.getBean("Question");
				           myQuestions=new ArrayList<Question>();
				          
				  do {
				    	  
					  Question  question=(Question) app.getBean("Question");
				    	   System.out.println("Enter the question number:");
				    	   int number=scr.nextInt();
				    	   System.out.println("Enter the question:");
				    	   String content=scr.next();
				    	   System.out.println("Enter the option A:");
				    	   String optionA=scr.next();
				    	   System.out.println("Enter the option B:");
				    	   String optionB=scr.next();
				    	   System.out.println("Enter the option C:");
				    	   String optionC=scr.next();
				    	
				    	   System.out.println("Enter the correct option:");
				    	   String correctOption=scr.next();
				    	   
				    	   
				    	   question.setNumber(number);
				    	   question.setContent(content);
				    	   question.setOptionA(optionA);
				    	   question.setOptionB(optionB);
				    	   question.setOptionC(optionC);
				    	   question.setCorrectOption(correctOption);
				    	   myQuestions.add(question);
				    	  
				    	   System.out.println("press 1 to continue adding questions/press 2 to exit");
				    	   choice=scr.nextInt();
				    	   
				      }while(choice!=2); 
				           
				           test.setName(testName);
					       test.setTotalquestions(totalquestions);
					       test.setTotalMarks(totalMarks);
					       test.setQuestions(myQuestions);
				           System.out.println(services.createMyTest(test));
				    	   
				  break;
				       
				/*case for finding the created test 
				 * It will return test and if not created  will throw an exception  
				 * last Modified 15/05/2019
			    */    
				case 2:    System.out.println("Enter the test to be searched:");
				           String tname=scr.next();
				           try {
				           Test testdetails= services.searchTestByName(tname);
				           System.out.println(testdetails);
				           }catch(TestNotFoundException e) {
				    	   System.out.println(e.getMessage());
				               }
				  break;
				
				 /*case for adding candidates
				  * this will add candidates 
				  * last Modified 15/05/2019
				 */
				case 3:    System.out.println("Enter the candidate id:");
					       id=scr.nextInt();
					       System.out.println("Enter the candidate name:");
					       String name=scr.next();
					   
					       Candidate candidate=(Candidate) app.getBean("Candidate");
					       candidate.setId(id);
					       candidate.setName(name);
					       candidateServices.addCandidate(candidate);
					       System.out.println(candidateServices.addCandidate(candidate));
					   
				  break;
				
				 /*case for assigning test to the candidate
				  *This will assign given test to the specified candidate id..If candidate is not present or test 
				  *is not created then will throw an exception 
				 */
				case 4:    System.out.println("Enter the id of the candidate to whom test is to be assigned");
				           int cid=scr.nextInt();
				           try {
				    	   candidate=candidateServices.searchById(cid);
				           }catch(CandidateNotFoundException e) {
				           System.out.println(e.getMessage()); break;}
					 				       
				           System.out.println("Enter the name of test:");
				           String testname=scr.next();
				           try { 
					    	 test= services.searchTestByName(testname);
					       }catch(TestNotFoundException e) {
					       System.out.println(e.getMessage());
					    	 break;
					       }
				           System.out.println("Enter date:");
				           Date date=new Date();
				           System.out.println(date.getDate());
				           Assigner assigner=new Assigner(date,test,candidate);
				           assignerServices.assignTestToCandidate(assigner);
				           System.out.println(assignerServices.assignTestToCandidate(assigner));
				   break;
				   
				/*This is exit case ...exits from the program*/   
				case 5:System.exit(0);
				}
			}while(choice!=6);
		} 
		
		public static void printDetails() {
			System.out.println("1. Create Test");
			System.out.println("2. Find   Test");
		    System.out.println("3. Add    Candidates");
			System.out.println("4. Assign Test");
			System.out.println("5.Exit");
		   }
	}


