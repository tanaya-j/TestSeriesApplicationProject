package com.cg.testseriesspring.service;

import java.util.List;

import com.cg.testseriesspring.dto.Test;

/*
 * This a test interface it includes methods for creating test ,searching test by name 
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */

public interface TestService {

	
	public Test createMyTest(Test test);
	public Test searchTestByName(String testName);
}
