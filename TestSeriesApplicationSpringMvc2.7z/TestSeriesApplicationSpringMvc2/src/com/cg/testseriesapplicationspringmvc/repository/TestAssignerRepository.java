package com.cg.testseriesapplicationspringmvc.repository;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;

/*
 * This a Test assigner repository  interface It saves the assigner
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav  */
public interface TestAssignerRepository {
	public Assigner save(Assigner assigner); 
}
