package com.cg.testseriesapplicationspringmvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.exception.CandidateAlreadyexistException;
import com.cg.testseriesapplicationspringmvc.util.DBUtilCandidate;
/*
 * This is a implementation of candidate repository which implements 
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav 
*/
@Repository("CandidateRepository")
public class CandidateRepositoryImp implements CandidateRepository {

	@PersistenceContext
	EntityManager em;
	
/*saves the candidate
	 * @param: candidate
	 * @return: candidate
	 * last Modified 15/05/2019  Author:Tanaya Jadhav
*/
	public Candidate saveCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		
		Candidate c=em.find(Candidate.class, candidate.getId());
		if(c!=null) {
			throw new CandidateAlreadyexistException("Id exist");
		}
		else {
		em.persist(candidate);
		em.flush();
		}
		return candidate;
	}

/*finds the candidate
	 * @param: id
	 * @return: candidate
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
		return em.find(Candidate.class,id);
	}

}
