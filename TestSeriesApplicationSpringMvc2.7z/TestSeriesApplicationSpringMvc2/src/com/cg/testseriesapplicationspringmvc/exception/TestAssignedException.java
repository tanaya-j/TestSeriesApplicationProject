package com.cg.testseriesapplicationspringmvc.exception;

public class TestAssignedException extends RuntimeException {

	public TestAssignedException() {
		// TODO Auto-generated constructor stub
	}

	public TestAssignedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
