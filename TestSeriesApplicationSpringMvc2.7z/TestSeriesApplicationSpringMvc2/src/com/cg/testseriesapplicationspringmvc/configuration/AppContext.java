package com.cg.testseriesapplicationspringmvc.configuration;



import java.util.Properties;
import javax.sql.DataSource;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration  // configures class
@EnableTransactionManagement  //enables the transaction
@PropertySource("classpath:resources/mysql.properties") //to read properties file
@ComponentScan("com.cg.testseriesapplicationspringmvc") // scans whole package
public class AppContext {
	
	@Autowired
	private Environment environment; //is an interface used to access other files

	
	//second step injecting data source in session factory
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(new String[] {"com.cg.testseriesapplicationspringmvc.dto" });//scans package where entity is created
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}


	//first step  is to create data source
	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environment.getRequiredProperty("mysql.driver"));
		dataSource.setUrl(environment.getRequiredProperty("mysql.url"));
		dataSource.setUsername(environment.getRequiredProperty("mysql.username"));
		dataSource.setPassword(environment.getRequiredProperty("mysql.password"));
		return dataSource;
	}

	//third step is to set hibernate properties
	private Properties hibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", environment.getRequiredProperty("mysql.dialect"));
		properties.put("hibernate.hbm2ddl.auto", environment.getRequiredProperty("mysql.auto"));
		//properties.put("hibernate.format_sql", true);
		return properties;
	}

	
	//session is injected in transaction manager
	@Bean
	public HibernateTransactionManager getTransactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory().getObject());
		return transactionManager;
	}
	

}
