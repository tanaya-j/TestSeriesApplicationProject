package com.cg.testseriesapplicationspringmvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/*
* This a Candidate bean class with the attributes as int id, String name
* Parameterized constructor , getter setters and toString methods..!
* last Modified 15/05/2019
 * Author:Tanaya Jadhav  */

@Entity
@Table(name="Candidate")
public class Candidate {
	   @Id
//	   @GeneratedValue(strategy=GenerationType.AUTO)
	   @Column(name="candidate_id")
	   private Integer id;//primary key
	   @Column(name="Name")
	   private String name;
	   
	   public Candidate() {}


	public Candidate(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "Candidate [id=" + id + ", name=" + name + "]";
	}


	
	   
	   
}
