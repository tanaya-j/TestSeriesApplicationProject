package com.cg.testseriesapplicationspringmvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationspringmvc.repository.CandidateRepositoryImp;
/*
 * This class is a implementation of candidate service interface.
 * It includes add candidate and search candidate by id methods.
 * last Modified 15/05/2019  Author:Tanaya Jadhav 
*/
@Transactional
@Service
public class CandidateServiceImp implements CandidateService{
	@Autowired
	CandidateRepositoryImp dao;
	
	
	
	/*This method is used to add candidates 
	 * @param: candidate
	 * @return: candidate  
	 last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Candidate addCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
     return	dao.saveCandidate(candidate);
	}

	
	/*This method is used to search candidate by id
	 * @param: id
	 * @return: candidate with that id   
	 *last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	
	public Candidate searchById(int id) {
		
		Candidate c=dao.findById(id);
		if(c==null) {
			throw new CandidateNotFoundException("ID NOT PRESENT");
		  }
		
		return c;
	}

}
