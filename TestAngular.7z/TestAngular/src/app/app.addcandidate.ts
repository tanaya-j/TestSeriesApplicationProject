import { Component } from "@angular/core";
import { TestService } from "./app.testService";
import { FormGroup, FormControl, Validators ,FormBuilder} from "@angular/forms";


@Component({
    selector:'add-cand',
    templateUrl:'addCandidate.html'
})


export class AddCandidate{
 

    addCandForm = this.fb.group({
        name: ['',Validators.required],
        
         
       });


    constructor(private service:TestService,private fb: FormBuilder){}
    model:any={};   
    addCandidate(){
        console.log(this.model);
        this.model.name=this.addCandForm.value.name;
        
        this.service.addCandidates(this.model).subscribe((data:any)=>console.log(data));
        alert("Candidate added succesfully");
    }
}


/* export class AddCandidate{
 
    cand=new FormGroup({
    name : new FormControl('')
    
    });  
     
    
    
        constructor(private service:TestService){}
        model:any={};   
        addCandidate(){
            console.log(this.model);
            this.service.addCandidates(this.model).subscribe((data:any)=>console.log(data));
        }
    }

 */