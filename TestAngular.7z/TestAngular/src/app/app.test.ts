import {Question} from './app.question'

export class Test{
    id:number;
    name:string;
    totalquestions:number;
    totalMarks:number;
    questions:Question[];
}