import { Test } from "./app.test";
import { Candidate } from "./app.candidate";

export class Assigner{
  id:number;
  test:Test;
  candidate:Candidate;
  date:Date;
}