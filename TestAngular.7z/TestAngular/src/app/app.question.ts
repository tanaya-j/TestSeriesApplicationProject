export class Question{
  
    content:string;
    optionA:string;
    optionB:string;
    optionC:string;
    correctOption:string;
}