import { Component } from "@angular/core";
import { TestService } from "./app.testService";
import { Question } from "./app.question";
import { FormGroup, FormControl } from "@angular/forms";

@Component({
    selector:'add-test',
    templateUrl:'addtest.html'
})

export class AddTest{
    test=new FormGroup({
        testname : new FormControl(''),
        totalquestion:new FormControl(''),
        totalmarks:new FormControl('')
     }); 

        quest=new FormGroup({
        content:new FormControl(''),
        optionA:new FormControl(''),
        optionB:new FormControl(''),
        optionC:new FormControl(''),
        correctOption:new FormControl('')
      })      
    constructor(private service:TestService){}
    model:any={};   
    testdata=false;
    questions:Question[]=[];
    question={
    content:'',
    optionA:'',
    optionB:'',
    optionC:'',
    correctOption:''
};

addQuestion(){
console.log(this.model);
this.testdata=true;
}


addQuestions(){
   this.questions.push(this.question);
   console.log(this.questions);
   this.question={
    content:'',
    optionA:'',
    optionB:'',
    optionC:'',
    correctOption:''
   }
}

    addTest(){
        this.questions.push(this.question);
        this.model['questions']=this.questions;
        console.log(this.model);
        this.service.addTests(this.model).subscribe((data=>console.log(data)));
        alert("Test added succesfully");
    }
}



/* export class AddTest{
    test=new FormGroup({
        testname : new FormControl(''),
        totalquestion:new FormControl(''),
        totalmarks:new FormControl('')
     }); 

        quest=new FormGroup({
        content:new FormControl(''),
        optionA:new FormControl(''),
        optionB:new FormControl(''),
        optionC:new FormControl(''),
        correctOption:new FormControl('')
      })      
    constructor(private service:TestService){}
    model:any={};   
    testdata=false;
    questions:Question[]=[];
    question={
    content:'',
    optionA:'',
    optionB:'',
    optionC:'',
    correctOption:''
};

addQuestion(){
console.log(this.model);
this.testdata=true;
}


addQuestions(){
   this.questions.push(this.question);
   console.log(this.questions);
   this.question={
    content:'',
    optionA:'',
    optionB:'',
    optionC:'',
    correctOption:''
   }
}

    addTest(){
        this.questions.push(this.question);
        this.model['questions']=this.questions;
        console.log(this.model);
        this.service.addTests(this.model).subscribe((data=>console.log(data)));
    }
} */