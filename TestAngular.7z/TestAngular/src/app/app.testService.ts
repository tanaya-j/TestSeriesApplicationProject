import {Injectable} from '@angular/core';
import { HttpClient, HttpParams} from '@angular/common/http';
import { Question } from './app.question';
import { throwError } from 'rxjs';
//import { Observable } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable({
     providedIn:'root'
})

export class TestService{

constructor(private http:HttpClient){}



addTests(test:any):any{
  var input=new FormData();
 let  i:number=0;
  input.append("name",test.name);
  input.append("totalMarks",test.totalMarks);
  input.append("totalquestions",test.totalquestions);
 console.log(test);
while(i<test.questions.length){
console.log(i);
input.append("questions["+i+"].content",test.questions[i].content);
input.append("questions["+i+"].optionA",test.questions[i].optionA);
input.append("questions["+i+"].optionB",test.questions[i].optionB);
input.append("questions["+i+"].optionC",test.questions[i].optionC);
input.append("questions["+i+"].correctOption",test.questions[i].correctOption);
i++;
} 
  return this.http.post("http://localhost:9098/test/addtest",input)
  .pipe(
    retry(1),
    catchError(this.handleError)
  );

}
  
addCandidates(cand:any){
  let input=new FormData();
  //input.append("id",cand.id);
  input.append("name",cand.name);
  return this.http.post("http://localhost:9098/test/addCandidate",input)
  .pipe(
    retry(1),
    catchError(this.handleError)
  );;
}


addAssigners(assign:any){
  let input=new FormData();
  input.append("test",assign.testid);
  input.append("candidate",assign.candidateid);
 
  return this.http.post("http://localhost:9098/test/assignTest",input)
  .pipe(
    retry(1),
    catchError(this.handleError)
  );
  }

searchTestByName(name:string){
  let httpParams=new HttpParams().set("name",name);
  return this.http.get("http://localhost:9098/test/searchTest",{params:httpParams});
}

handleError(error) {
  let errorMessage = '';
  if (error.error instanceof ErrorEvent) {
    // client-side error
    errorMessage = `Error: ${error.error}`;
  } else {
    // server-side error
    errorMessage = `Message: ${error.error}`;
  }
  window.alert(errorMessage);
  return throwError(errorMessage);
}

}