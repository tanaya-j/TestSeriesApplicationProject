import { Component } from "@angular/core";
import { TestService } from "./app.testService";
import { FormControl, FormGroup, FormBuilder, Validators } from "@angular/forms";


@Component({
    selector:'assign',
    templateUrl:'addassigner.html'
})


export class AddAssigner{
    
    addassignForm = this.fb.group({
        candidateid: ['',Validators.required],
        testid: ['',Validators.required],
        
         
       });
    constructor(private service:TestService,private fb: FormBuilder){}
    model:any={};   
    addAssigner(){
        console.log(this.model);
        this.model.candidateid=this.addassignForm.value.candidateid;
        this.model.name=this. addassignForm.value.name;
        this.service.addAssigners(this.model).subscribe((data:any)=>console.log(data));
        alert("Test Assigned succesfully");
    }
}



/* export class AddAssigner{
    
    assign=new FormGroup({
    candidateid : new FormControl(''),
    testid:new FormControl('')
        
        }); 
    constructor(private service:TestService){}
    model:any={};   
    addAssigner(){
        console.log(this.model);
        this.service.addAssigners(this.model).subscribe((data:any)=>console.log(data));
    }
}
 */