import { Component } from "@angular/core";
import { TestService } from "./app.testService";
import { Test } from "./app.test";
import { FormControl, FormGroup } from "@angular/forms";

@Component({
    selector:'search-test',
    templateUrl:'search.html'
})


export class SearchTest{

   search=new FormGroup({
        name : new FormControl('')
            
            }); 
    constructor(private service:TestService){}
    model:any={};  
    test:Test[];
    name:string; 
   
    searchTest(){
        this.service.searchTestByName(this.name).subscribe((data:any)=>this.test=data);
    }
}