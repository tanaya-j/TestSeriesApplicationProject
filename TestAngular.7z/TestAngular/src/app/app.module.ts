﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { Routes,RouterModule } from '@angular/router';
import { FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AddCandidate } from './app.addcandidate';
import { AddTest } from './app.addtest';
import { AddAssigner } from './app.addAssigner';
import { SearchTest } from './app.search';
import { ReactiveFormsModule } from '@angular/forms'; 



const route:Routes=[
    {path:"addCandidate",component:AddCandidate},
    {path:"createTest",component:AddTest},
    {path:"assignTest",component:AddAssigner},
    {path:"searchTest",component:SearchTest}

    


]

@NgModule({
    imports: [
        BrowserModule,RouterModule.forRoot(route),FormsModule,HttpClientModule, ReactiveFormsModule 
        
    ],
    declarations: [
        AppComponent,AddCandidate,AddTest,AddAssigner,SearchTest
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }